# Copyright (c) 1999-2016, Juniper Networks Inc.
#
# All rights reserved.
#

__import__('pkg_resources').declare_namespace(__name__)
